
package dat.prac3.controller;

import dat.fw.web.app.WebApp;
import dat.fw.web.handler.HandlerData;
import dat.fw.web.html.Html;

import dat.fw.util.*;

import dat.prac3.model.dao.DAOFactory;

import javax.servlet.ServletContext;


public class MsgApp
{

    public final DAOFactory daoFact;

    public MsgApp(ServletContext servletContext) throws Exception {
        daoFact = new dat.prac3.model.sqldao.SqlDAOFactory(
                servletContext.getInitParameter("message_app.db.url"),
                servletContext.getInitParameter("message_app.db.user"),
                servletContext.getInitParameter("message_app.db.password")
	);
    }


    //------------------- Type class instances ------------------------

    public static WebApp<MsgApp> WebApp = new WebApp<MsgApp>();

}

