#!usr/bin/expect
#			LOGIN SSH 
set HOST "soft0.upc.edu"
set USER "ldatusr12"
set PASSWORD "8h3w0fnz"
spawn ssh -p 6767 $USER@$HOST
expect "password:"
send "$PASSWORD\r"
expect "$ "
send "clear \r"
expect "$ "
#			1.WE MOVE TO THE CORRECT FOLDER FOR COMPILE
send "cd project-schema\r"
expect "$ "
#			2.WE DELETE OLDER AND CREATE A NEW DATABASE
send "./bin/drop-db.sh\r"
expect "$ "
send "./bin/create-db.sh\r"
expect "$ "
#			3.WE COMPILE
send "chmod +x ./bin/compile.sh\r"
expect "$ "
send "./bin/compile.sh\r"
expect "$ "
#			4.WE COPY THE MAIL.CGI TO THE WEB PAGE FOLDER (public_html)
send "cp build/bin/mail.cgi ../public_html/practica2  \r"
expect "$ "

#			EXIT SSH 
send "exit \r"
expect "$ "