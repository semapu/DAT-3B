#!/bin/bash
expect upload.sh
expect compile.sh

