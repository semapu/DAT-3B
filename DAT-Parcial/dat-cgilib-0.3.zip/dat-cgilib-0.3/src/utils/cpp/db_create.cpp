
#include "../../lib/c/ddb_c.h"

#include <iostream>


int main(int argc, char **argv)
{
    /* Arguments:
     *		argv[1]		database's directory
     */
    if (argc != 2) {
    	std::cout << "Usage:  " << argv[0] << "  <db_dir>" << std::endl;
    	return 1;
    }

    if (DB_create_db(argv[1]) != 0) {
    	std::cout << "Cannot create database '" << argv[1] << "'" << std::endl;
    	return 1;
    }

    return 0;
}


