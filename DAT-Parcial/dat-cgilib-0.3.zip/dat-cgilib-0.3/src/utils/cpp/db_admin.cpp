
#include <dat_db/ddb.hpp>

#include <iostream>

using namespace std;
using namespace dat_db;

string db_prog, db_dir, command;

class UsageException : public std::exception {
  public:
    std::string args;

  public:
    UsageException(const std::string& args) {
        this->args = args;
    }
    ~UsageException() throw () {}
    const char *what() const throw () {
        static std::string mem;
        mem = "Usage: " + db_prog + "  <db_dir>  " + command + "  " + args; 
        return mem.c_str(); 
    }
};

int do_command(int argc, char **argv);

int main(int argc, char **argv)
{
    /* Arguments:
     *		argv[1]		database's directory
     *		argv[2]		command
     *		argv[>=3]	command args
     */
    db_prog = argv[0];
    if (argc < 3) {
        cout << "Usage: " << db_prog << "  <db_dir>  <command>  [<args>...]" << endl;
        cout << "Available commands:" << endl;
        cout << "       create-table    create a new table" << endl;
        cout << "       drop-table      drop an existent table" << endl;
        cout << "       select          select and show records of a table" << endl;
        cout << "       insert          insert a record in a table" << endl;
        cout << "       delete          delete records from a table" << endl;
        cout << "       update          modify records of a table" << endl;
        cout << "Try '" << db_prog << " <command>' for more information" << endl;
        return 1;
    }
    db_dir = argv[1];
    command = argv[2];

    try {
        return do_command(argc - 3, argv + 3);
    } catch (UsageException& e) {
        cout << "Usage: " << db_prog << "  <db_dir>  " << command << "  " << e.args << endl;
        return 1;
    } catch (DBException& e) {
        cout << "Database exception: " << e.what() << endl;
        return 1;
    } catch (std::exception& e) {
        cout << "Exception: " << e.what() << endl;
        return 1;
    }
}

void create_table(DBConnection& dbc, int argc, char **argv);
void drop_table(DBConnection& dbc, int argc, char **argv);
void select(DBConnection& dbc, int argc, char **argv);
void insert(DBConnection& dbc, int argc, char **argv);
void delete_(DBConnection& dbc, int argc, char **argv);
void update(DBConnection& dbc, int argc, char **argv);

int do_command(int argc, char **argv)
{
    DBConnection dbc(db_dir);
    if (command == "create-table") {
        create_table(dbc, argc, argv);
        return 0;
    } else if (command == "drop-table") {
        drop_table(dbc, argc, argv);
        return 0;
    } else if (command == "select") {
        select(dbc, argc, argv);
        return 0;
    } else if (command == "insert") {
        insert(dbc, argc, argv);
        return 0;
    } else if (command == "delete") {
        delete_(dbc, argc, argv);
        return 0;
    } else if (command == "update") {
        update(dbc, argc, argv);
        return 0;
    } else {
        cout << "Invalid command: " << command << endl;
        cout << "Try '" << db_prog << "' with no command for available commands" << endl;
        return 1;
    }
}

void create_table(DBConnection& dbc, int argc, char **argv)
{
    std::list<std::string> cnames;
    int i;

    /* Arguments:
     *		argv[0]		name of table to create
     *		argv[1]		name of first column
     *		...		...
     *		argv[argc-1]	name of last column
     */
    if (argc < 2) {
    	throw UsageException ("<table_name>  <col1_name>  [<col2_name>...]");
    }

    for (i = 1; i < argc; i++) {
    	cnames.push_back (argv[i]);
    }
    dbc.create_table (argv[0], cnames);
}

void drop_table(DBConnection& dbc, int argc, char **argv)
{
    /* Arguments:
     *		argv[0]		name of table to remove
     */
    if (argc != 1) {
    	throw UsageException ("<table_name>");
    }

    dbc.drop_table (argv[0]);
}

void select(DBConnection& dbc, int argc, char **argv)
{
    /* Arguments:
     *		argv[0]		name of table
     *		argv[1]		name of column with values to select
     *		argv[2]		value to select
     */
    if (argc != 1 && argc != 3) {
        throw UsageException ("<table_name>  [<select_name>  <select_value>]");
    }

    string table = argv[0];
    if (argc == 3) {
        dbc.select (table, argv[1],argv[2]);
    } else {
        dbc.select (table);
    }

    list<string> cnames = dbc.table_attrs(table);
    if (cnames.size() == 0) {
        cout << "Table " << table << " with no colums" << endl;
        return;
    }

    for (auto it = cnames.cbegin(); it != cnames.cend(); it++) {
        if (it != cnames.cbegin()) cout << "\t";
        cout << *it;
    }
    cout << endl << "======================================" << endl;
    while (dbc.next()) {
        for (auto it = cnames.cbegin(); it != cnames.cend(); it++) {
            if (it != cnames.cbegin()) cout << "\t";
            cout << dbc.get(*it);
        }
        cout << endl;
    }
}

void insert(DBConnection& dbc, int argc, char **argv)
{
    std::list<std::string> cvalues;
    int i;

    /* Arguments:
     *		argv[0]		name of table to insert
     *		argv[1]		name of first value
     *		...		...
     *		argv[argc-1]	name of last value
     */
    if (argc < 2) {
    	throw UsageException ("<table_name>  <value1>  [<value2>...]");
    }

    for (i = 1; i < argc; i++) {
    	cvalues.push_back (argv[i]);
    }
    dbc.insert (argv[0], cvalues);
}

void delete_(DBConnection& dbc, int argc, char **argv)
{
    /* Arguments:
     *		argv[0]		name of table to delete
     *		argv[1]		name of column with values to select
     *		argv[2]		value to select
     */
    if (argc != 1 && argc != 3) {
    	throw UsageException ("<table_name>  [<select_name>  <select_value>]");
    }

    if (argc == 3) {
	dbc.delete_rows(argv[0], argv[1], argv[2]);
    } else {
	dbc.delete_rows(argv[0]);
    }
}

void update(DBConnection& dbc, int argc, char **argv)
{
    /* Arguments:
     *		argv[0]		name of table to update
     *		argv[1]		name of column to update
     *		argv[2]		new value
     *		argv[3]		name of column with values to select
     *		argv[4]		value to select
     */
    if (argc != 3 && argc != 5) {
    	throw UsageException ("<table_name>  <col_name>  <value>  [<select_col>  <select_value>]");
    }

    if (argc == 5) {
	dbc.update(argv[0], argv[1], argv[2], argv[3], argv[4]);
    } else {
	dbc.update(argv[0], argv[1], argv[2]);
    }
}



