/*  coding.hpp
 *
 * Conte utilitats per a codificar/decodificar cadenes de 
 * caracters en format URL i URL-Form.
 */


#ifndef _DAT_HTTP_CODING_
#define _DAT_HTTP_CODING_

#include <dat_base/text.hpp>
#include <dat_base/maybe.hpp>
#include <list>

namespace dat_http {


    /** Obté la codificació URL de la cadena <code>decoded</code>.
     * La sintaxi d'aquesta codificació és:
     * <pre>
     *  URLcoded-string:  string codificat de la seg&uuml;ent forma
     *  	Les lletres i els digits ('A'..'Z', 'a'..'z', '0'..'9')
     *  		es deixen igual.
     *  	Els espais (' ') es codifiquen amb '+'.
     *  	Els altres caracters es codifiquen amb la sequencia
     *  		'%xx' on xx es el codi ASCII hexadecimal del caracter.
     * </pre>
     */
    dat_base::ByteString url_encode(const dat_base::ByteString &decoded);

    /** Obté la decodificació URL de la cadena <code>encoded</code>. */
    dat_base::ByteString url_decode(const dat_base::ByteString &encoded);

    /** Obté la codificació URL-form del conjunt de parelles <code>params</code>. */
    dat_base::ByteString urlform_encode(const std::list<std::pair<dat_base::ByteString,dat_base::Maybe<dat_base::ByteString>>> &params);

    /** Obté la decodificació URL-form de la cadena <code>encoded</code>.
     *  La codificació URL-form és la codificació que fan normalment tots els
     * navegadors WEB abans de passar les dades del formulari al servidor.
     * <p>La sintaxi d'aquesta codificació és:</p>
     * <pre>
     *  form-coding:	form-field *('&' form-field)
     *  form-field:	field-name '=' field-value
     *  field-name:	URLcoded-string
     *  field-value:	URLcoded-string
     *  URLcoded-string:  (veieu la funció <code>URL_encode()</code>)
     * </pre>
     */
    std::list<std::pair<dat_base::ByteString,dat_base::Maybe<dat_base::ByteString>>> urlform_decode(const dat_base::ByteString &encoded);


}

#endif


