
#ifndef _DAT_HTTP_APP_
#define _DAT_HTTP_APP_

#include <dat_http/status.hpp>
#include <dat_base/text.hpp>
#include <dat_base/maybe.hpp>
#include <map>
#include <list>

namespace dat_http {

typedef dat_base::CIByteString HeaderName;
typedef std::pair<HeaderName,dat_base::ByteString> Header;

typedef std::list<Header> RequestHeaders;
typedef std::list<std::pair<dat_base::ByteString,dat_base::Maybe<dat_base::ByteString>>> Query;

class Request {
  struct Rep {
    dat_base::ByteString meth, rawPI, rawQS;
    RequestHeaders hdrs;
    dat_base::Maybe<unsigned> bodyLen;
    std::function<dat_base::ByteString()> bodyFun;
    Query *parsedQS;

    Rep(
        const dat_base::ByteString &method,
        const dat_base::ByteString &rawPathInfo, const dat_base::ByteString &rawQueryString,
        const RequestHeaders &headers,
        const dat_base::Maybe<unsigned> &bodyLength,
        const std::function<dat_base::ByteString()> &getBody
    ) : meth(method), rawPI(rawPathInfo), rawQS(rawQueryString), hdrs(headers), bodyLen(bodyLength), bodyFun(getBody), parsedQS(0) {}
    ~Rep() { delete parsedQS; }
    Rep(const Rep &) = delete;
    Rep & operator=(const Rep &) = delete;
  };
  std::shared_ptr<Rep> rep;

public:
    Request(
        const dat_base::ByteString &method,
        const dat_base::ByteString &rawPathInfo, const dat_base::ByteString &rawQueryString,
        const RequestHeaders &headers,
        const dat_base::Maybe<unsigned> &bodyLength,
        const std::function<dat_base::ByteString()> &getBody
    ) : rep(new Rep(method, rawPathInfo, rawQueryString, headers, bodyLength, getBody)) {}

/**
Returns the name of the HTTP method with which this request was made, for example, GET, POST, or PUT.
@returns  a string specifying the name of the method with which the request was made
 */
    const dat_base::ByteString &method() const { return rep->meth; }

    const dat_base::ByteString &rawPathInfo() const { return rep->rawPI; }

    std::list<dat_base::Text> pathInfo() const;

/**
Returns the query string that is contained in the request URL after the path.
Same as the value of the environment variable QUERY_STRING.
@returns  a string containing the query string. Nothing if the URL does not have a query string.
 */
    const dat_base::ByteString & rawQueryString() const { return rep->rawQS; }

    const Query & queryString() const;

    const RequestHeaders &headers() const { return rep->hdrs; }

    dat_base::Maybe<dat_base::ByteString> lookupHeader(const HeaderName &name) const;

/**
Returns the length, in bytes, of the request body and made available by the input stream.
Same as the value of the environment variable CONTENT_LENGTH.
@returns  an integer containing the length of the request body.
@throws
    if the variable CONTENT_LENGTH is undefined
 */
    const dat_base::Maybe<unsigned> &bodyLength() const { return rep->bodyLen; }

    dat_base::ByteString getBody() const { return rep->bodyFun(); }

}; // End of class Request


typedef std::list<Header> ResponseHeaders;

typedef std::function<void(std::ostream &out)> StreamingBody;

class Response {
    Status status;
    ResponseHeaders headers;
    StreamingBody body;
public:
    Response(const Status & st, const ResponseHeaders &hs, const dat_base::ByteString &b);
    Response(const Status & st, const ResponseHeaders &hs, const StreamingBody &b) : status(st), headers(hs), body(b) {}

    const Status &responseStatus() const { return status; }
    const ResponseHeaders &responseHeaders() const { return headers; }
    const StreamingBody &responseBody() const { return body; }

}; // End of class Response


/**
A string specifying the MIME type of the HTML content
 */
extern dat_base::ByteString MIME_HTML;

/**
A string specifying the MIME type of the URL-form encoded content
 */
extern dat_base::ByteString MIME_URLFORM;


} // end of namespace

#endif


