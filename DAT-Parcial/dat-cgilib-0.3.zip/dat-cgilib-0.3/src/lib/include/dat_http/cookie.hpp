
#ifndef _DAT_HTTP_COOKIE_
#define _DAT_HTTP_COOKIE_

#include <dat_base/text.hpp>
#include <dat_base/maybe.hpp>
#include <list>

namespace dat_http {

/**
A cookie is a small amount of information sent by a server to a Web browser, saved by the browser, and later sent back to the server.
A cookie's value can uniquely identify a client, so cookies are commonly used for session management.

A cookie has a name, a single value, and optional attributes such as path and domain qualifiers and a maximum age.
The value can be anything the server chooses to send. Its value is probably of interest only to the server.

The CGI sends cookies to the browser by using the response::addCookie() method,
which adds headers to HTTP response to send cookies to the browser, one at a time.
The browser is expected to support 20 cookies for each Web server, 300 cookies total, and may limit cookie size to 4 KB each.

The browser returns cookies to the server by adding fields to HTTP request headers.
Cookies can be retrieved from a request by using the request::cookies() method.
Several cookies might have the same name but different path attributes. 
 */
class SetCookie {
  private:
    dat_base::ByteString name_;
    dat_base::ByteString value_;
    dat_base::Maybe<dat_base::ByteString> path_;
    dat_base::Maybe<unsigned int> maxAge_;

  public:
/**
 * Constructs a cookie with a specified name and value.
 */
    SetCookie(const dat_base::ByteString& name, const dat_base::ByteString& value,
              const dat_base::Maybe<dat_base::ByteString>& path, const dat_base::Maybe<unsigned int>& maxAge) {
        this->name_ = name;
        this->value_ = value;
        this->path_ = path;
        this->maxAge_ = maxAge;
    }
/**
 * Constructs a cookie with default values.
*/
    SetCookie() {
        this->name_ = "name";
        this->value_ = "value";
    }

/**
 * Sets the name of the cookie (returns the modified cookie).
 * The name must conform to RFC 6265. That means it can contain ASCII characters excluding control characters, separators and white space.
 */
    SetCookie name(const dat_base::ByteString& val) const {
        return SetCookie(val, value_, path_, maxAge_); 
    }

/** The name of the cookie. */
    const dat_base::ByteString& name() const { return name_; }

/**
 * Sets the value of the cookie (returns the modified cookie).
 * The value must conform to RFC 6265. That means it can contain ASCII characters excluding control characters, white space,
 * double quote, comma, semicolon, and backslash.
 */
    SetCookie value(const dat_base::ByteString& val) const {
        return SetCookie(name_, val, path_, maxAge_); 
    }

/** The value of the cookie. */
    const dat_base::ByteString& value() const { return value_; }

/**
 * Sets the path of the cookie (returns the modified cookie).
 */
    SetCookie path(const dat_base::Maybe<dat_base::ByteString>& val) const {
        return SetCookie(name_, value_, val, maxAge_); 
    }

/** The path of the cookie. */
    const dat_base::Maybe<dat_base::ByteString>& path() const { return path_; }

/**
 * Sets the maximum age of the cookie (returns the modified cookie).
 * The (optional) value is a delta in seconds from the time the cookie is received by the client.
 */
    SetCookie maxAge(const dat_base::Maybe<unsigned int>& val) const {
        return SetCookie(name_, value_, path_, val); 
    }

/** The maximum age of the cookie. */
    const dat_base::Maybe<unsigned int>& maxAge() const { return maxAge_; }

};

/**
 * Get the value of a "SetCookie" response header.
 */
dat_base::ByteString renderSetCookie(const SetCookie&);


/**
 * Client to server cookies
 */

typedef std::list<std::pair<dat_base::ByteString, dat_base::ByteString>> Cookies;

/**
 * Parse the value of a "Cookie" request header into key/value pairs.
 */
Cookies parseCookies(const dat_base::ByteString&);

} // End of namesapce dat_http

#endif


