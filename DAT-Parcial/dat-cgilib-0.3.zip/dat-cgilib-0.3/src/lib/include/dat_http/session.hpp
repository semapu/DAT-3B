
#ifndef _DAT_HTTP_SESSION_
#define _DAT_HTTP_SESSION_

#include <dat_http/app.hpp>
#include <string>
#include <map>

namespace dat_http {

typedef std::map<std::string,std::string> SessionMap;

typedef std::function<ResponseHeaders(const SessionMap &)> SaveSession;

std::pair<SessionMap,SaveSession> clientLoadSession(const Request &);

}

#endif


