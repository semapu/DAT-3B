
#ifndef _DAT_HTTP_CGI_
#define _DAT_HTTP_CGI_

#include <dat_http/app.hpp>

namespace dat_http {

void cgiApp(char **env, const std::function<Response(const Request &)> &app);

} // end of namespace

#endif


