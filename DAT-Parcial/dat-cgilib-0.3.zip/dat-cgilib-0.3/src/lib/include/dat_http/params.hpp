
#ifndef _DAT_HTTP_PARAMS_
#define _DAT_HTTP_PARAMS_

#include <dat_http/app.hpp>

namespace dat_http {

dat_http::Query postParams(const dat_http::Request &request);

dat_base::Maybe<dat_base::ByteString> lookupParam(const dat_base::ByteString& name, const dat_http::Query &params);

std::list<dat_base::ByteString> lookupParams(const dat_base::ByteString& name, const dat_http::Query &params);

inline bool hasParam(const dat_base::ByteString& name, const dat_http::Query &params) {
    return isJust(lookupParam(name, params));
}

} // End of namesapce dat_http

#endif


