
#ifndef _DAT_HTTP_STATUS_
#define _DAT_HTTP_STATUS_

#include <string>

namespace dat_http {

class Status {
    int code_;
    std::string message_;
public:
    Status(int c, const std::string &m) : code_(c), message_(m) {}

    int code() const { return code_; }
    const std::string &message() const { return message_; }

}; // End of class Status


// Successful 2xx

extern Status ok200;

// Redirection 3xx

/** The requested resource has been assigned a new permanent URI and any future references to this resource SHOULD use the returned URI
 * (in the Location header).
 */
extern Status movedPermanently301;

/** The response to the request can be found under a different URI (in the Location header)
 * and SHOULD be retrieved using a GET method on that resource.
 * This method exists primarily to allow the output of a POST-activated script to redirect the user agent to a selected resource.
 * The new URI is not a substitute reference for the originally requested resource.
 */
extern Status seeOther303;

/** The request should be repeated with the returned URI (in the Location header).
 * However, future requests should still use the original URI (in contrast with the 301 status).
 */
extern Status temporaryRedirect307;

// Client Error 4xx

/** The request could not be understood by the server due to malformed syntax. The client SHOULD NOT repeat the request without modifications.
 */
extern Status badRequest400;

extern Status unauthorized401;
extern Status forbidden403;
extern Status notFound404;
extern Status methodNotAllowed405;

// Server Error 5xx

/** The server encountered an unexpected condition which prevented it from fulfilling the request.
 */
extern Status internalServerError500;

}

#endif


