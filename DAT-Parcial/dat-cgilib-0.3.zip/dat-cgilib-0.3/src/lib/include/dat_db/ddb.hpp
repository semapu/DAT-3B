
#ifndef _DAT_DB_DDB_
#define _DAT_DB_DDB_

#include <dat_base/except.hpp>
#include <list>

namespace dat_db {


class DBException : public dat_base::LibException {
  public:
    DBException(const std::string& msg) : LibException(msg) {}

    std::string str() const { return "DBException: " + message; }
};


/** La classe <code>DBConnection</code> representa una connexió d'accés a la base de dades. */
class DBConnection {
  private:
    void* rep_;

    // Hide the copy constructor and the copy assignment constructor
    DBConnection(const DBConnection& other);
    DBConnection& operator=(const DBConnection& other);

  public:
/** Crea una connexió amb la base de dades.
 * En cas d'error, llança una <code>DBException</code>.
 */
    DBConnection(const std::string& db_directory);

/** Allibera la connexió. */
    ~DBConnection();

/*********************************************************/
/* Database management */

/** Crea una taula amb el nom indicat en 'table' i els camps indicats en 'cols'.
 * En cas d'error, llança una <code>DBException</code>.
 */
    void create_table(const std::string& table, const std::list<std::string>& cols);
/**
 * Elimina la taula indicada
 */
    void drop_table(const std::string& table);

/** Obté la llista de noms dels camps definits en la taula indicada.
 * En cas d'error (p.ex. no existeix la taula), llança una <code>DBException</code>.
 */
    std::list<std::string> table_attrs(const std::string& table);

/**
 * Obté en una taula temporal (interna) el conjunt dels registres de la
 * taula 'table' en els que el valor del camp 'sname' és igual a 'svalue'.
 * Després d'aquesta operació, caldrà utilitzar 'next()' per posicionar-se
 * al primer registre del resultat.
 * En cas d'error, llança una <code>DBException</code>.
 */
    void select(const std::string& table, const std::string& sname, const std::string& svalue) {
        select_(table, sname.c_str(), svalue.c_str());
    }
/**
 * Obté en una taula temporal (interna) tots els registres de la taula 'table'.
 * Després d'aquesta operació, caldrà utilitzar 'next()' per posicionar-se
 * al primer registre del resultat.
 * En cas d'error, llança una <code>DBException</code>.
 */
    void select(const std::string& table) {
        select_(table, 0, 0);
    }
/**
 * Avança el cursor de registre actual.
 * Retorna true si i sols si pot avançar (no ha arribat al final del resultat). 
 * En cas d'error, llança una <code>DBException</code>.
 */
    bool next();
/**
 * Obté el valor del camp 'cname' del registre actual. 
 * En cas d'error, llança una <code>DBException</code>.
 */
    std::string get(const std::string& cname);

/**
 * Afegeix un registre en la taula 'table'.
 * 'cvalues' és la llista de valors dels camps del registre.
 * La quantitat i l'ordre dels valors ha de correspondre a la quantitat i ordre
 * dels camps definits en la taula indicada.
 * En cas d'error, llança una <code>DBException</code>.
 */
    void insert(const std::string& table, const std::list<std::string>& cvalues);

/**
 * Modifica el valor del camp 'uname' al valor 'uvalue'
 * dels registres de la taula 'table' que tenen el camp 'sname' igual a 'svalue'.
 * En cas d'error, llança una <code>DBException</code>.
 */
    void update(const std::string& table, const std::string& uname, const std::string& uvalue,
        const std::string& sname, const std::string& svalue
    ) {
        update_(table, uname, uvalue, sname.c_str(), svalue.c_str());
    }
/**
 * Modifica el valor del camp 'uname' al valor 'uvalue'
 * de tots els registres de la taula 'table'.
 * En cas d'error, llança una <code>DBException</code>.
 */
    void update(const std::string& table, const std::string& uname, const std::string& uvalue) {
        update_(table, uname, uvalue, 0, 0);
    }

/**
 * Elimina els registres que tenen el camp 'sname' igual a 'svalue'.
 * En cas d'error, llança una <code>DBException</code>.
 */
    void delete_rows(const std::string& table, const std::string& sname, const std::string& svalue) {
        delete_(table, sname.c_str(), svalue.c_str());
    }
/**
 * Elimina tots els registres de la taula.
 * En cas d'error, llança una <code>DBException</code>.
 */
    void delete_rows(const std::string& table) {
        delete_(table, 0, 0);
    }

  private:
    void select_(const std::string& table, const char* sname, const char* svalue);
    void update_(const std::string& table, const std::string& uname, const std::string& uvalue,
                                          const char* sname, const char* svalue);
    void delete_(const std::string& table, const char* sname, const char* svalue);

    void check_table_has_attr(const std::string& table, const std::string& aname);
};


} // end of namespace

#endif
