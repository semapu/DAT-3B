
#ifndef _DAT_BASE_MAYBE_
#define _DAT_BASE_MAYBE_

#include <dat_base/except.hpp>

#include <memory>

namespace dat_base {


template< class X >
class Maybe {
    std::shared_ptr<X> ptr;
public:
    Maybe() : ptr(nullptr) {}
    Maybe(const X& x) : ptr(new X(x)) {}

    bool isNothing() const {
        return ptr == nullptr;
    }
    bool isJust() const {
        return ptr != nullptr;
    }
    const X& fromJust() const {
        if (ptr == nullptr) throw LibException("fromJust: argument is Nothing");
        return *ptr;
    }
};

template< class X > Maybe<X> Just( const X& x ) { return Maybe<X>(x); }

template< class X > Maybe<X> Nothing() { return Maybe<X>(); }

template< class X > bool isNothing( const Maybe<X>& m ) { return m.isNothing(); }

template< class X > bool isJust( const Maybe<X>& m ) { return m.isJust(); }

template< class X > const X& fromMaybe(const X &def, const Maybe<X>& m ) {
    if (m.isNothing()) {
        return def;
    } else {
        return m.fromJust();
    }
}

template< class X > const X& fromJust( const Maybe<X>& m ) { return m.fromJust(); }


} // end of namespace dat_base

#endif
