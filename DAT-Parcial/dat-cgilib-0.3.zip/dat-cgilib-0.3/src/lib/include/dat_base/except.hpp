
#ifndef _DAT_BASE_EXCEPT_
#define _DAT_BASE_EXCEPT_

#include <string>
#include <exception>

namespace dat_base {


class LibException : public std::exception {
  protected:
    std::string message;

  public:
    LibException(const std::string& msg) {
        message = msg;
    }
    ~LibException() throw () {}

    const char *what() const throw () { return message.c_str(); }

    virtual std::string str() const { return "LibException: " + message; }
};


} // end of namespace dat_base

#endif


