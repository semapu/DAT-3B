
#ifndef _DAT_BASE_TEXT_
#define _DAT_BASE_TEXT_

#include <string>
#include <cwctype>

namespace dat_base {

typedef wchar_t Char;
typedef std::wstring Text;


typedef char Byte;
typedef std::basic_string<char> ByteString;


// case-insensitive traits for Text (strings of wide char):
struct ciws_traits: std::char_traits<wchar_t> {
  static bool eq (wchar_t c, wchar_t d) { return std::towlower(c)==std::towlower(d); }
  static bool lt (wchar_t c, wchar_t d) { return std::towlower(c)<std::towlower(d); }
  static int compare (const wchar_t* p, const wchar_t* q, std::size_t n) {
    while (n--) {if (!eq(*p,*q)) return lt(*p,*q); ++p; ++q;}
    return 0;
  }
};

typedef std::basic_string<wchar_t,ciws_traits> CIText;


// case-insensitive traits for byte strings:
struct cibs_traits: std::char_traits<char> {
  static bool eq (char c, char d) { return std::tolower(c)==std::tolower(d); }
  static bool lt (char c, char d) { return std::tolower(c)<std::tolower(d); }
  static int compare (const char* p, const char* q, std::size_t n) {
    while (n--) {if (!eq(*p,*q)) return lt(*p,*q); ++p; ++q;}
    return 0;
  }
};

typedef std::basic_string<char,cibs_traits> CIByteString;

}

#endif


