/*  coding_pp.cpp
 *
 * Data: 7-Oct-2015
 */

#include <dat_http/coding.hpp>

#include "../c/urlcoding.h"
#include <stdlib.h>     // free()
#include <string.h>

namespace dat_http {

using namespace dat_base;

/**************************************************************************/
/* URL encoding/decoding */

std::string url_encode(const std::string &decoded)
{
    char *c_encoded = URL_encode(decoded.c_str(), decoded.size());
    std::string encoded(c_encoded);
    free(c_encoded);
    return encoded;
}


std::string url_decode(const std::string &encoded)
{
    char *c_decoded = URL_decode(encoded.c_str(), encoded.size());
    std::string decoded(c_decoded);
    free(c_decoded);
    return decoded;
}


/**************************************************************************/
/* URL-Form encoding/decoding */

std::string urlform_encode(const std::list<std::pair<std::string,Maybe<std::string>>> &params)
{
    using namespace std;
    string result;
    for (list<pair<string,Maybe<string>>>::const_iterator mit = params.begin();
         mit != params.end(); ++mit)
    {
        if (! result.empty()) {
            result.append("&");
        }
        result.append(url_encode(mit->first));
        const Maybe<string> &value = mit->second;
        if (isJust(value)) {
	    result.append("=").append(url_encode(fromJust(value)));
	}
    }
    return result;
}


std::list<std::pair<std::string,Maybe<std::string>>>  urlform_decode(const std::string &encoded)
{
    using namespace std;
    list<pair<string,Maybe<string>>> parsedQS;
        const char *first = encoded.c_str();
	while (true) {
	    const char *last, *sep;
	    last = strchr(first, '&');	/* Es la posicio del seguent separador de camps */
	    if (last == nullptr) {
		last = first + strlen(first);
	    }
	    sep = strchr(first, '=');	/* Es la posicio del separador entre nom i valor */
	    if (sep == nullptr || sep >= last) {
	        string name = url_decode(string(first, (last-first)));
	        parsedQS.push_back(pair< string,Maybe<string> >(name, Nothing<string>()));
	    } else {
	        string name = url_decode(string(first, (sep-first)));
	        string value = url_decode(string(sep+1, (last-sep)-1));
	        parsedQS.push_back(pair< string,Maybe<string> >(name, Just(value)));
	    }
	    if (*last == 0) {
		break;
	    }
	    first = last + 1;	/* Mou a l'inici del seguent camp */
	}
    return parsedQS;
}

} // end of namespace


