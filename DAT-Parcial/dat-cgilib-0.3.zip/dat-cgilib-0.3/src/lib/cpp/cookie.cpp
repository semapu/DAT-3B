
#include <dat_http/cookie.hpp>

#include <tuple>
#include <string>

namespace dat_http {

using namespace dat_base;

/****************************************************************
 * Request cookies
 */

static std::pair<ByteString,ByteString> breakDiscard(char w, ByteString s)
{
    size_t pos = s.find(w, 0);
    if (pos == std::string::npos) {
        return std::pair<ByteString,ByteString>(s, "");
    } else {
        return std::pair<ByteString,ByteString>(s.substr(0, pos), s.substr(pos + 1));
    }
}

static std::pair<ByteString,ByteString> parseCookie(ByteString s)
{
    std::pair<ByteString,ByteString> key_value = breakDiscard('=', s);
    ByteString key = key_value.first;
    size_t pos = 0;
    // drop spaces
    while ((pos=key.find(' ', pos)) != std::string::npos) {
        key = key.erase(pos, 1);
    }
    return std::pair<ByteString,ByteString>(key, key_value.second);
}

/* parse Cookie request header field body (see RFC 6265) */
Cookies parseCookies(const ByteString& headerval)
{
    if (headerval.empty()) {
        return Cookies();
    } else {
        std::pair<ByteString,ByteString> cookie_next = breakDiscard(';', headerval);
        std::pair<ByteString,ByteString> cookie = parseCookie(cookie_next.first);
        Cookies next = parseCookies(cookie_next.second);
        next.push_front(cookie);
        return next;
    }
}


/****************************************************************
 * Response cookies
 */

#define SP              ' '
#define HT              '\t'
#define DEL             '\x7f'
#define SPHT            " \t"
#define SEPARATORS      "()<>@,;:\\\"/[]?={} \t"

ByteString renderSetCookie(const SetCookie& sCookie)
{
    ByteString buf;
    /* Set Path attribute for PATH_INFO independence */
    buf.append(sCookie.name()).append("=").append(sCookie.value());
    if (isJust(sCookie.path())) {
        buf.append("; Path=").append(fromJust(sCookie.path()));
    }
    if (isJust(sCookie.maxAge())) {
        buf.append("; Max-Age=").append(std::to_string(fromJust(sCookie.maxAge())));
    }
    return buf;
}


} // end of namespace dat_http


