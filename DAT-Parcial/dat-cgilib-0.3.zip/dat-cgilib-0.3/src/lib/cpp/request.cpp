
#include <dat_http/app.hpp>
#include <dat_http/coding.hpp>

namespace dat_http {

using namespace dat_base;

std::string MIME_HTML =    "text/html;charset=utf-8";
std::string MIME_URLFORM = "application/x-www-form-urlencoded";


const Query & Request::queryString() const {
    using namespace std;
    if (rep->parsedQS == 0) {
        rep->parsedQS = new list<pair< string,Maybe<string> >>();
        string rawQS = rawQueryString();
        if (rawQS.size() > 0) {
            *rep->parsedQS = urlform_decode(rawQS.substr(1));
        }
    }
    return *rep->parsedQS;
}


Maybe<std::string> Request::lookupHeader(const HeaderName &name) const
{
    using namespace std;
    for (list<Header>::const_iterator it = rep->hdrs.begin();
         it != rep->hdrs.end(); ++it)
    {
        if (it->first == name) return Just(it->second);
    }
    return Nothing<string>();
}

} // end of namespace dat_http


