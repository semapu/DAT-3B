
#include <dat_http/params.hpp>
#include <dat_http/coding.hpp>

namespace dat_http {

using namespace std;
using namespace dat_base;
using namespace dat_http;

Query postParams(const Request &request)
{
    Query params;
    if (request.method() == "POST") {
        Maybe<string> mbh = request.lookupHeader("Content-Type");
        if (isJust(mbh) && fromJust(mbh) == MIME_URLFORM) {
            string encoded;
            while (true) {
                string r = request.getBody();
                if (r.size() == 0) break;
                encoded = encoded + r;
            }
            params = urlform_decode(encoded);
        }
    }
    return params;
}

Maybe<ByteString> lookupParam(const ByteString& name, const Query &qs)
{
    for (list<pair<string,Maybe<string>>>::const_iterator vit = qs.begin();
         vit != qs.end(); ++vit)
    {
        if (vit->first == name) {
            Maybe<string> mbv = vit->second;
            if (isJust(mbv)) {
                return mbv;
            }
        }
    }
    return Nothing<string>();
}

list<string> lookupParams(const ByteString& name, const Query &qs)
{
    list<string> values;
    for (list<pair<string,Maybe<string>>>::const_iterator vit = qs.begin();
         vit != qs.end(); ++vit)
    {
        if (vit->first == name) {
            Maybe<string> mbv = vit->second;
            if (isJust(mbv)) {
                values.push_back(fromJust(mbv));
            }
        }
    }
    return values;
}

} // End of namesapce dat_http


