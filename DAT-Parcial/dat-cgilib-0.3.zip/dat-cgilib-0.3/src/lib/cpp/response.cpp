
#include <dat_http/app.hpp>

#include <iostream>
#include <sstream>

#include <stdlib.h>     // getenv()


/****************************************************************
 * Generic CGI processing
 */

namespace dat_http {

Response::Response(const Status & st, const ResponseHeaders &hs, const dat_base::ByteString &b)
    : status(st), headers(hs), body([=](std::ostream &out) { out << b; })
{
}


// Status codes:

Status ok200(200, "OK");

Status movedPermanently301(301, "Moved Permanently");
Status seeOther303(303, "See Other");
Status temporaryRedirect307(307, "Temporary Redirect");

Status badRequest400(400, "Bad Request");
Status notFound404(404, "Not Found");
Status methodNotAllowed405(405, "Method Not Allowed");

Status internalServerError500(500, "Internal Server Error");


} // end of namespace dat_http


