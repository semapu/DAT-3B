
#include <dat_http/cgi.hpp>
#include <dat_http/coding.hpp>
#include <tuple>
#include <iostream>
#include <memory>
#include <string.h>

namespace dat_http {

using namespace dat_base;

static Request makeRequest(char **env);
static void sendHeader(Header h);
static void errorOutput(std::string msg);

void cgiApp(char **env, const std::function<Response(const Request &)> &app)
{
    //***cgilib_prepare_debug();
    try {
        // Construct request
        Request request = makeRequest(env);
        // Run application
        Response response = app(request);
        // Send status
        Status status = response.responseStatus();
        std::cout << "Status: " << status.code() << " " << status.message() << std::endl;
        // Send headers
        for (ResponseHeaders::const_iterator it = response.responseHeaders().cbegin(); it != response.responseHeaders().cend(); ++it) {
            sendHeader(*it);
        }
        std::cout << std::endl;
        std::cout.flush();
        // Send body
        response.responseBody()(std::cout);
    } catch (const LibException& e) {
        errorOutput("LibException: " + e.str());
    } catch (const std::exception& e) {
        errorOutput(std::string("Standard exception: ") + e.what());
    } catch (...) {
        errorOutput("Unknown exception");
    }
}

static void errorOutput(std::string msg)
{
    std::cout << "Status: 500 Internal Server Error" << std::endl;
    std::cout << "Content-Type: text/plain" << std::endl;
    std::cout << std::endl;
    std::cout << msg << std::endl;
    std::cout.flush();
}

//-------- Construct the request

static std::string getEnv(const char* name) {
    char * s = getenv(name);
    if (s == nullptr) {
        return "";
    } else {
        return s;
    }
}

static HeaderName convertName(const char *ename);

static RequestHeaders envToHeaders(char** env)
{
    RequestHeaders hs;
    for (int i = 0; env[i] != nullptr; i++) {
        char *eqp = strchr(env[i], '=');
        if (eqp != nullptr) {
            *eqp = 0;
            //***v.push_back(std::pair<std::string,std::string>(env[i], eqp+1));
            if (strcmp(env[i], "CONTENT_TYPE") == 0) {
                hs.push_back(Header("Content-Type", eqp + 1));
            } else if (strcmp(env[i], "CONTENT_LENGTH") == 0) {
                hs.push_back(Header("Content-Length", eqp + 1));
            } else if (strncmp(env[i], "HTTP_", 5) == 0) {
                hs.push_back(Header(convertName(env[i] + 5), eqp + 1));
            }
            *eqp = '=';
        }
    }
    return hs;
}

static HeaderName convertName(const char *ename)
{
    using namespace std;
    HeaderName result = ename;
    unsigned i = 0;
    while (i < result.size()) {
        i++;
        while (i < result.size()) {
            if (result[i] == '_') {
                result[i] = '-';
                i++;
                break;
            } else {
                result[i] = tolower(result[i]);
                i++;
            }
        }
    }
    return result;
}

static std::function<std::string()> get_content(unsigned bodyLength)
{
    std::shared_ptr<unsigned> ref(new unsigned); *ref = bodyLength;
    return [=]() -> std::string {
        unsigned length = *ref;
        if (length <= 0) {
            return "";
        } else {
            unsigned n = 32000; if (length < n) n = length;
            char buf[32000];
            if (std::cin.get(buf, n)) {
                std::string chunk = buf;
                *ref = (*ref) - n;
                return chunk;
            } else {
                return "";
            }
        }
    };
}

static Request makeRequest(char **env)
{
    using namespace std;
    string method = getEnv("REQUEST_METHOD");
    string pathInfo = getEnv("PATH_INFO");
    char* c_query = getenv("QUERY_STRING");
    char* c_contentLen = getenv("CONTENT_LENGTH");
    unsigned contentLength = (c_contentLen == nullptr) ? 0 : atoi(c_contentLen);
    RequestHeaders headers = envToHeaders(env);
    return Request(
        method,
        pathInfo, (c_query == nullptr) ? "" : string("?")+c_query,
        headers,
        Just(contentLength), get_content(contentLength)
    );
}


//-------- Send headers

static void sendHeader(Header h)
{
    std::cout << h.first.c_str() << ": " << h.second << std::endl;
}


} // end of namespace cgilib


