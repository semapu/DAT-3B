
#include <dat_http/session.hpp>
#include <dat_http/cookie.hpp>
#include <dat_http/coding.hpp>

#include <stdlib.h>     // srand(), rand()
#include <unistd.h>     // getpid()
#include <time.h>       // time()
#include <stdio.h>      // sprintf()

namespace dat_http {

using namespace std;
using namespace dat_base;

/****************************************************************
 * Random generation
 */

static int random_state = 0;

static int random_getByte()
{
    if (random_state == 0) {
        srand((unsigned int) (time(NULL) ^ getpid()));
    }
    do {
        srand((unsigned int) (random_state ^ getpid() ^ time(NULL)));
        random_state = rand();
    } while (random_state == 0);
    return random_state;
}

static void random_getBytes(char *addr, unsigned len)
{
    while (len > 0) {
        addr[--len] = (char) random_getByte();
    }
}


/****************************************************************
 * Session management
 */

const string SESSION_COOKIENAME = "_SESSION_";
const unsigned SESSION_MAXINACTIVETIME = 600;     /* 10 minutes */


static SessionMap decodeCookie(const ByteString &cookieValue)
{
    SessionMap map;
    list<pair<ByteString,Maybe<ByteString>>> pairs = urlform_decode(cookieValue);
    for (list<pair<ByteString,Maybe<ByteString>>>::const_iterator it = pairs.cbegin(); it != pairs.cend(); ++it) {
        if (isJust(it->second)) {
            map.insert(pair<ByteString,ByteString>(it->first, fromJust(it->second)));
        }
    }
    return map;
}

static ByteString encodeCookie(const SessionMap &session)
{
    list<pair<ByteString,Maybe<ByteString>>> pairs;
    for (SessionMap::const_iterator it = session.cbegin(); it != session.cend(); ++it) {
        pairs.push_back(pair<ByteString,Maybe<ByteString>>(it->first, Just(it->second)));
    }
    return urlform_encode(pairs);
}


static void scanCookies(const Cookies &cookies, list<ByteString> &values)
{
    for (Cookies::const_iterator pos = cookies.cbegin(); pos != cookies.cend(); ++pos) {
        pair<ByteString,ByteString> c = *pos;
        if (c.first == SESSION_COOKIENAME) {
            values.insert(values.end(), c.second);
        }
    }
}

static void scanHeaders(const RequestHeaders &headers, list<ByteString> &values)
{
    for (RequestHeaders::const_iterator pos = headers.cbegin(); pos != headers.cend(); ++pos) {
        Header h = *pos;
        if (h.first == "Cookie") {
            Cookies cookies = parseCookies(h.second);
            scanCookies(cookies, values);
        }
    }
}

static ResponseHeaders saveSession(const SessionMap &session)
{
    ByteString cookieValue = encodeCookie(session);
    ByteString cpath = "/"; // TODO: The application path from getenv("SCRIPT_NAME")
    SetCookie setCookie = SetCookie().name(SESSION_COOKIENAME).value(cookieValue).
        path(Just(cpath)).maxAge(Just(SESSION_MAXINACTIVETIME));
    return list<Header>(1, Header("Set-Cookie", renderSetCookie(setCookie)));
}

pair<SessionMap,SaveSession> clientLoadSession(const Request &request)
{
    RequestHeaders headers = request.headers();
    list<ByteString> values;
    scanHeaders(headers, values);
    SessionMap session;
    for (list<ByteString>::const_iterator pos = values.cbegin(); pos != values.cend(); ++pos) {
        SessionMap map = decodeCookie(*pos);
        session.insert(map.cbegin(), map.cend());
    }
    return pair<SessionMap,SaveSession>(session, saveSession);
}

} // End of namespace dat_http


