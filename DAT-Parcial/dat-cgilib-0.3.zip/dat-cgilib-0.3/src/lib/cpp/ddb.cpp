
#include <dat_db/ddb.hpp>
#include "../c/ddb_c.h"

#include <algorithm>
#include <sstream>
#include <stdlib.h>     // free()


namespace dat_db {

DBConnection::DBConnection(const std::string& db_directory) {
    rep_ = DBC_open(db_directory.c_str());
    if (rep_ == nullptr) {
        throw DBException ("Cannot open connection with database (db_directory is '" + db_directory + "')");
    }
}

DBConnection::~DBConnection() {
    DBC_close((DBConn_p) rep_);
    rep_ = nullptr;
}


void DBConnection::create_table(const std::string& table, const std::list<std::string>& anames) {
    DBConn_p rep = (DBConn_p) this->rep_;
    StrList list = StrList_create();
    for (std::list<std::string>::const_iterator it = anames.begin(); it != anames.end(); ++it) {
        StrList_add(list, it->c_str());
    }
    int status = DBC_create_table(rep, table.c_str(), list);
    StrList_destroy(list);
    if (status != 0) {
        if (DBC_table_attrs(rep, table.c_str()) != 0) {
            throw DBException (std::string(rep->db_root) + ": create_table: table '" + table + "' already exist");
        }
        throw DBException (std::string(rep->db_root) + ": create_table: '" + table + "'");
    }
}

void DBConnection::drop_table(const std::string& table) {
    DBConn_p rep = (DBConn_p) this->rep_;
    int status = DBC_drop_table(rep, table.c_str());
    if (status != 0) {
        throw DBException (std::string(rep->db_root) + ": drop_table: '" + table + "'");
    }
}

std::list<std::string> DBConnection::table_attrs(const std::string& table) {
    DBConn_p rep = (DBConn_p) this->rep_;
    StrList anames = DBC_table_attrs(rep, table.c_str());
    if (anames == 0) {
        throw DBException (std::string(rep->db_root) + ": invalid table '" + table + "'");
    }
    std::list<std::string> names;
    for (int i = 0; i < StrList_size(anames); i++) {
        names.push_back(StrList_get(anames, i));
    }
    StrList_destroy(anames);
    return names;
}

void DBConnection::check_table_has_attr(const std::string& table, const std::string& aname) {
    DBConn_p rep = (DBConn_p) this->rep_;
    std::list<std::string> anames = table_attrs(table);
    std::list<std::string>::iterator it = find (anames.begin(), anames.end(), aname);
    if (it == anames.end()) {
        throw DBException (std::string(rep->db_root) + ": table '" + table + "': invalid attribute '" + aname + "'");
    }
}


void DBConnection::select_(const std::string& table, const char* sname, const char* svalue) {
    DBConn_p rep = (DBConn_p) this->rep_;
    int status = DBC_select(rep, table.c_str(), sname, svalue);
    if (status != 0) {
        if (sname != 0) {
            check_table_has_attr(table, sname);
        } else {
            table_attrs(table);
        }
        throw DBException (std::string(rep->db_root) + ": select: '" + table + "'");
    }
}

bool DBConnection::next() {
    DBConn_p rep = (DBConn_p) this->rep_;
    if (StrList_size(rep->result_names) == 0) {
        throw DBException (std::string(rep->db_root) + ": next");
    }
    return DBC_next(rep) == 0;
}

std::string DBConnection::get(const std::string& aname) {
    DBConn_p rep = (DBConn_p) this->rep_;
    if (StrList_index(rep->result_names, aname.c_str()) == -1) {
        throw DBException (std::string(rep->db_root) + ": get: invalid attribute '" + aname + "'");
    }
    char* cs = DBC_get(rep, aname.c_str());
    if (cs == 0) {
        throw DBException (std::string(rep->db_root) + ": get");
    }
    std::string s(cs);
    free(cs);
    return s;
}


void DBConnection::insert(const std::string& table, const std::list<std::string>& values) {
    DBConn_p rep = (DBConn_p) this->rep_;
    StrList cvalues = StrList_create();
    for (std::list<std::string>::const_iterator vit = values.begin(); vit != values.end(); ++vit)
    {
        StrList_add(cvalues, vit->c_str());
    }
    int status = DBC_insert(rep, table.c_str(), cvalues);
    StrList_destroy(cvalues);
    if (status != 0) {
        std::stringstream msg; msg << rep->db_root << ": insert: '" << table << "'";
        std::list<std::string> anames = table_attrs(table);
        if (values.size() != anames.size()) {
            msg << ": " << values.size() << " values (expected " << anames.size() << ")";
        }
        throw DBException (msg.str());
    }
}


void DBConnection::update_(const std::string& table, const std::string& uname, const std::string& uvalue, const char* sname, const char* svalue) {
    DBConn_p rep = (DBConn_p) this->rep_;
    int status = DBC_update(rep, table.c_str(), uname.c_str(), uvalue.c_str(), sname, svalue);
    if (status != 0) {
        check_table_has_attr(table, uname);
        if (sname != 0) {
            check_table_has_attr(table, sname);
        }
        throw DBException (std::string(rep->db_root) + ": update: '" + table + "'");
    }
}


void DBConnection::delete_(const std::string& table, const char* sname, const char* svalue) {
    DBConn_p rep = (DBConn_p) this->rep_;
    int status = DBC_delete(rep, table.c_str(), sname, svalue);
    if (status != 0) {
        if (sname != 0) {
            check_table_has_attr(table, sname);
        } else {
            table_attrs(table);
        }
        throw DBException (std::string(rep->db_root) + ": delete_rows: '" + table + "'");
    }
}

} // end of namespace


