/*  urlcoding.c
 *
 * Data: 18-Oct-1999
 *
 * URLcoded-string:  string codificat de la seg&uuml;ent forma
 *		Les lletres i els digits ('A'..'Z', 'a'..'z', '0'..'9')
 *			es deixen igual.
 *		Els espais (' ') es codifiquen amb '+'.
 *		Els altres caracters es codifiquen amb la sequencia
 *			'%xx' on xx es el codi ASCII hexadecimal del caracter.
 *
 */

#include "urlcoding.h"
#include <string.h>
#include <stdlib.h>


/**************************************************************************/
/* URL encoding/decoding */

char *URL_encode(const char *s, unsigned len)
{
	char *buf = (char*)malloc(3*len+1);
	int last = 0;
	int i;

	for(i=0; i<len; i++) {
	    int c = (unsigned char)s[i];
	    if( (c>='0' && c<='9') 
		|| (c>='A' && c<='Z') || (c>='a' && c<='z') ) {
		buf[last++] = c;
	    } else if (c==' ') {
		buf[last++] = '+';
	    } else {
		char b;
		buf[last++] = '%';
		b = c / 16;
		if (b < 10) {
		    b = b + '0';
		} else {
		    b = b - 10 + 'A';
		}
		buf[last++] = b;
		b = c % 16;
		if (b < 10) {
		    b = b + '0';
		} else {
		    b = b - 10 + 'A';
		}
		buf[last++] = b;
	    }
	}

	buf[last] = 0;
	return buf;
}


static int digit_value(char c)
{
    if ('a'<=c && c<='f') {
	return c-'a'+10;
    } else
    if ('A'<=c && c<='F') {
	return c-'A'+10;
    } else {
	return c-'0';
    }
}

char *URL_decode(const char *s, unsigned len)
{
	char *buf = (char*)malloc(len+1);
	int last = 0;
	int i=0;

	while (i<len) {
	    int c = (unsigned char)s[i];
	    if( c=='%') {
		int b = digit_value(s[i+1]);
		b = b*16 + digit_value(s[i+2]);
		i = i+2;
		buf[last++] = b;
	    } else if (c=='+') {
		buf[last++] = ' ';
	    } else {
		buf[last++] = c;
	    }
	    i++;
	}

	buf[last] = 0;
	return buf;
}

