
#include <dat_http/cgi.hpp>
#include <dat_http/params.hpp>
#include <dat_db/ddb.hpp>

#include <string>

using namespace std;
using namespace dat_base;
using namespace dat_http;
using namespace dat_db;

Response tasksApp(Request request);

int main(int argc, char **argv, char **env)
{
    cgiApp(env, tasksApp);
    return 0;
}


string db_dir = "tasks-db";

Response get(); // Request is not used
Response post(const Request &request);
Response errorResponse(const Status & status, const string& msg);

Response tasksApp(Request request)
{
    try {
        if (request.method() == "GET") {
            return get();
        } else if (request.method() == "POST") {
            return post(request);
        } else {
            return errorResponse(methodNotAllowed405, "Invalid request method " + request.method());
        }

    } catch (const LibException& e) {
        return errorResponse(internalServerError500, "LibException: " + e.str());
    } catch (const std::exception& e) {
        return errorResponse(internalServerError500, string("Standard exception: ") + e.what());
    } catch (...) {
        return errorResponse(internalServerError500, "Unknown exception");
    }
}


/****************************************************************
 * Task operations
 */

Response add(const Query &params);
Response mark(const Query &params);
Response remove(const Query &params);
ByteString pageHtml();

Response get()
{
    ResponseHeaders hs;
    hs.push_back(Header("Content-Type", MIME_HTML));
    return Response(ok200, hs, pageHtml());
}

Response post(const Request &request)
{
    Query params = postParams(request);
    if (hasParam("add", params)) {
        /* add new task action from form */
        return add(params);
    } else if (hasParam("mark", params)) {
        /* mark done tasks action from form */
        return mark(params);
    } else if (hasParam("delete", params)) {
        /* delete tasks action from form */
        return remove(params);
    } else {
        return errorResponse(badRequest400, "Invalid POST action");
    }
}

string new_seq();

Response add(const Query &params)
{
    Maybe<string> mbtitle = lookupParam("title", params);
    if (isJust(mbtitle)) {
        string title = fromJust(mbtitle);
        string id = new_seq();
        DBConnection dbc(db_dir);
        list<string> record;
        record.push_back(id);       // attribute 'id'
        record.push_back(title);    // attribute 'title'
        record.push_back("false");  // attribute 'done'
        dbc.insert("tasks", record);
        return get();
    } else {
        return errorResponse(badRequest400, "Required parameter: 'title'");
    }
}

string new_seq()
{
    DBConnection dbc(db_dir);
    dbc.select("sequence");
    if (! dbc.next()) {
        throw DBException("Table 'sequence' with no rows");
    }
    string val = dbc.get("value");
    val = to_string(stoi(val) + 1);
    dbc.update("sequence", "value", val);
    return val;
}

Response mark(const Query &params)
{
    list<string> ids = lookupParams("id", params);
    DBConnection dbc(db_dir);
    for (auto it = ids.cbegin(); it != ids.cend(); it++) {
        dbc.update("tasks", "done", "true", "id", *it);
    }

    return get();
}

Response remove(const Query &params)
{
    list<string> ids = lookupParams("id", params);
    DBConnection dbc(db_dir);
    for (auto it = ids.cbegin(); it != ids.cend(); it++) {
        dbc.delete_rows("tasks", "id", *it);
    }

    return get();
}


/****************************************************************
 * Output HTML
 */

string html_escaped(const string& text)
{
    string result;
    for (unsigned i = 0; i < text.size(); i++) {
        char c = text[i];
        switch (c) {
            case '<': result += "&lt;"; break;
            case '&': result += "&amp;"; break;
            case '>': result += "&gt;"; break;
            case '\"': result += "&quot;"; break;
            case '\'': result += "&apos;"; break;
            default:  result += c; break;
        }
    }
    return result;
}

ByteString pageHtml()
{
    ByteString html;
    DBConnection dbc(db_dir);

    html.append("<html><head>\n").
        append("<title>Exemple CGI Lib: Tasques</title>\n").
        append("</head><body>\n").
        append("<h1>Exemple de CGI Lib: Tasques</h1>\n").
        append("<form method=\"POST\" action=\"#\">\n").
        append("Afegeix tasca:<br>\n").
        append("<input type=\"text\" name=\"title\"><br>\n").
        append("<input type=\"submit\" name=\"add\" value=\"Afegeix\">\n").
        append("<hr>\n");

    dbc.select("tasks");
    while (dbc.next()) {
        bool done = dbc.get("done") == "true";
        html.append("<input type=\"checkbox\" name=\"id\" value=\"").append(dbc.get("id")).append("\">\n");
        if (done) {
            html.append("<span>FET</span> <span>").append(html_escaped(dbc.get("title"))).append("</span>\n");
        } else {
            html.append("<span>PENDENT</span> <span>").append(html_escaped(dbc.get("title"))).append("</span>\n");
        }
        html.append("<br>\n");
    }
    html.append("<input type=\"submit\" name=\"delete\" value=\"Elimina\">\n").
        append("<input type=\"submit\" name=\"mark\" value=\"Marca FET\">\n").
        append("</form>\n").
        append("</body></html>\n");
    return html;
}

Response errorResponse(const Status & status, const string& msg)
{
    ResponseHeaders hs = list<Header>(1, Header("Content-Type", MIME_HTML));
    ByteString html;
    html.append("<html><head><title>Exemple CGI Lib: Tasques</title></head><body>\n").
        append("<center><h2>ERROR</h2><h3><FONT COLOR=\"red\">").append(msg).append("</FONT></h3></center>\n").
        append("<p><a href=\"#\">Llista de tasques</a></p>\n").
        append("</body></html>\n");
    return Response(status, hs, html);
}

