
Contenido
=========

    README        Este fichero.
    Makefile      Makefile para la construcción de la biblioteca, las utilidades y la aplicación.
    src/lib/      Fuentes de la biblioteca.
    src/utils/    Fuentes de las utilidades.
    src/examples/ Ejemplos de aplicación (CGI, HTML, ...).
    lib/          Biblioteca de soporte (compilada para los ordenadores del laboratorio).
    bin/          Utilidades para la gestión de la base de datos (compiladas para los ordenadores del laboratorio).


Construcción de la biblioteca de soporte (build/lib/web-pract2.a) y las utilidades (build/bin/*)
===============================================================================================

 1. Situarse en este directorio.

 2. Ejecutar 'make bins'.


Construcción del ejemplo
========================

 1. Situarse en este directorio.

 2. Ejecutar 'make all'.
    Esto construirà un directorio 'build' con el CGI de ejemplo.

 3. Copiar el programa 'build/example.cgi' construido al lugar adecuado de su servidor WEB.

 3. Copiar las páginas 'src/example/www/*.html' al lugar adecuado de su servidor WEB.


